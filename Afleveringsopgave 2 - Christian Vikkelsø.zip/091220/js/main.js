var handleClick = function () {
  document.getElementById("overskrift").innerHTML =
    "Surprise! Nu er den skrevet med JavaScript.";
  document.getElementById("knap").style.display = "none";
};

var button = document.getElementById("knap");

button.addEventListener("click", handleClick);
